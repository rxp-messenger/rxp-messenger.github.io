MSN Messenger Clone for RebornXP
--------------------
BUGS
--------------------
NUDGE
* Must be 2 users and both must click nudge for it to work.
* The message created by nudge is duplicated on the left depending on how many times nudge is clicked.
--------------------
